package com.evmtv.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.evmtv.entity.Student;
import com.evmtv.entity.User;

@Repository
public class UserDao {
    @Autowired
    private SessionFactory sessionFactory;

    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    public void deleteByPrimaryKey(Integer id) {
        getSession().delete(id);
    }

    public void insert(User record) {
        getSession().save(record);
    }

    public User selectByPrimaryKey(Integer id) {
        return (User) getSession().get(User.class, id);
    }

    public void updateByPrimaryKey(User record) {
        getSession().update(record);
    }

    public List<User> findAll() {
        return getSession().createQuery("from User").list();
    }

    public List<User> findByUserIds(List<Integer> userIds) {
        String sql = "from  User where id in (:alist)";
        Query query = getSession().createQuery(sql);
        return query.setParameterList("alist", userIds).list();
    }
}