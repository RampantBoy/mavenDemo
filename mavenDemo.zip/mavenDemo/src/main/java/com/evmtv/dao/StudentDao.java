package com.evmtv.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.evmtv.entity.Student;

@Repository
public class StudentDao {
	@Autowired
	private SessionFactory sessionFactory;

	private Session getSession() {
		return sessionFactory.getCurrentSession();
	}

	public void deleteByPrimaryKey(Integer id) {
		getSession().delete(id);
	}

	public void insert(Student student) {
		getSession().save(student);

	}

	public Student selectByPrimaryKey(Integer id) {
		return (Student)getSession().get(Student.class, id);

	}

	public void updateByPrimaryKey(Student student) {
		getSession().update(student);
	}

	@SuppressWarnings("unchecked")
	public List<Student> findAll() {
		String sql = "select * from student";
		return getSession().createQuery(sql).list();

	}

	@SuppressWarnings("unchecked")
	public List<Student> findByUserIds(List<Integer> userIds) {
		String sql = "select * from student where student_id in (" + userIds + ")";
		return getSession().createQuery(sql).list();
	}
}
