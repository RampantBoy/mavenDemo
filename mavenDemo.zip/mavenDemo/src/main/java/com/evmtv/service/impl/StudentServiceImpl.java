package com.evmtv.service.impl;

import com.evmtv.dao.StudentDao;
import com.evmtv.entity.Student;
import com.evmtv.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {
	@Autowired
	private StudentDao studentMapper;

	public boolean insert(Student student) {
		studentMapper.insert(student);
		return true;
	}

}
