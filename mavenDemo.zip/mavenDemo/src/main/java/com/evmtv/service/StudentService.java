package com.evmtv.service;

import com.evmtv.entity.Student;

public interface StudentService {
    boolean insert(Student student);
}
